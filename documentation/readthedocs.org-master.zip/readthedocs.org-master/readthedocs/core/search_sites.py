import haystack


haystack.autodiscover()
