default_app_config = 'readthedocs.donate.apps.DonateAppConfig'
