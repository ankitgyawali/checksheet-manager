:mod:`readthedocs.bookmarks`
============================

:mod:`readthedocs.bookmarks.admin`
----------------------------------
.. automodule:: readthedocs.bookmarks.admin
    :members:

:mod:`readthedocs.bookmarks.models`
-----------------------------------
.. automodule:: readthedocs.bookmarks.models
    :members:

:mod:`readthedocs.bookmarks.urls`
---------------------------------
.. automodule:: readthedocs.bookmarks.urls
    :members:

:mod:`readthedocs.bookmarks.views`
----------------------------------
.. automodule:: readthedocs.bookmarks.views
    :members:


