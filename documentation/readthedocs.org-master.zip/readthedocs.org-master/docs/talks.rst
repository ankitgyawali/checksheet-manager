Talks about Read the Docs
=========================

.. note:: This page is mainly just for showing a demo of updating docs, during a talk.

* PDX Python, May 2011
* OS Bridge, June 2011
* OSCON, July 2011
* Djangocon, July 2011
* OS Bridge, June 2014
